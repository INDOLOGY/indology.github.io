/*
  
 * ud2ur.c -- convert from Unicode Devanagari to Unicode Roman
 * using the ISO 15919 conventions.
 
* Both input and output are UTF-8 only. All Roman letters in the output
* are lower-case. All Devanāgarī numerals are converted.

* The use of the colon to distinguish the vowel-sequences a:i, a:u from
* ai and au is supported. However, it did not seem worth the effort to
* try to support sequences such as k:ha (= क्ह).

* As of now (2018-06-20) anusvāra is converted to ṁ and candrabindu
* to m̐. An option to allow these to be converted to tilde over a
* preceding long vowel might be worth considering.

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define CONVLISTSIZE (sizeof convlist / sizeof convlist[0])
#define CONSSIZE (sizeof cons / sizeof cons[0])
#define MEDVOWELSIZE (sizeof medvowel / sizeof medvowel[0])
#define HALANT 0x094D

FILE *infile;
int consfound = 0;
int afound = 0;

unsigned int cons[] = {
  0x0915,					/* k, kh, g, gh, ṅ */
  0x0916,
  0x0917,
  0x0918,
  0x0919,
  0x091A,					/* c, ch, j, jh, ñ */
  0x091B,
  0x091C,
  0x091D,
  0x091E,
  0x091F,					/* ṭ, ṭh, ḍ, ḍh, ṇ */
  0x0920,
  0x0921,
  0x0922,
  0x0923,
  0x0924,					/* t, th, d, dh, n */
  0x0925,
  0x0926,
  0x0927,
  0x0928,
  0x092A,					/* p, ph, b, bh, m */
  0x092B,
  0x092C,
  0x092D,
  0x092E,
  0x092F,					/* y, r, l, v */
  0x0930,
  0x0932,
  0x0935,
  0x0936,					/* ś, ṣ, s, h */
  0x0937,
  0x0938,
  0x0939,
  0x095C,					/* ṛ, ṛh, ḷ */
  0x095D,
  0x0933,
  0x0958,					/* q, x, ġ, f, z */
  0x0959,
  0x095A,
  0x095E,
  0x095B
};

unsigned int medvowel[]= {
  0x093E,					/* medial ā, i, ī, u, ū */
  0x093F,
  0x0940,
  0x0941,
  0x0942,
  0x0943,					/* medial r̥, r̥̄, l̥, l̥̄ */
  0x0944,
  0x0962,
  0x0963,
  0x0947,					/* medial e, ai, o, au */
  0x0948,
  0x094B,
  0x094C
};

/*
 * convinfo defines a struct containing (1) a Devanagari character,
 * (2) its Roman equivalent. Convlist lists all cases.
 */
struct convinfo {
  unsigned int dch;
  unsigned char *tch;
};

struct convinfo convlist[] = {
  {0x093D, "’"},				/* avagraha */
  {0x0905, "a"},
  {0x0906, "ā"},
  {0x093E, "ā"},
  {0x0907, "i"},
  {0x093F, "i"},
  {0x0908, "ī"},
  {0x0940, "ī"},
  {0x0909, "u"},
  {0x0941, "u"},
  {0x090A, "ū"},
  {0x0942, "ū"},
  {0x090B, "r̥"},
  {0x0943, "r̥"},
  {0x0960, "r̥̄"},
  {0x0944, "r̥̄"},
  {0x090C, "l̥"},
  {0x0962, "l̥"},
  {0x0961, "l̥̄"},
  {0x0963, "l̥̄"},
  {0x090F, "e"},
  {0x0947, "e"},
  {0x0913, "o"},
  {0x094B, "o"},
  {0x0910, "ai"},
  {0x0948, "ai"},
  {0x0914, "au"},
  {0x094C, "au"},
  {0x0901, "m̐"},
  {0x0902, "ṁ"},
  {0x0903, "ḥ"},
  {0x0915, "k"},
  {0x0916, "kh"},
  {0x0917, "g"},
  {0x0918, "gh"},
  {0x0919, "ṅ"},
  {0x091A, "c"},
  {0x091B, "ch"},
  {0x091C, "j"},
  {0x091D, "jh"},
  {0x091E, "ñ"},
  {0x091F, "ṭ"},
  {0x0920, "ṭh"},
  {0x0921, "ḍ"},
  {0x0922, "ḍh"},
  {0x0923, "ṇ"},
  {0x0924, "t"},
  {0x0925, "th"},
  {0x0926, "d"},
  {0x0927, "dh"},
  {0x0928, "n"},
  {0x092A, "p"},
  {0x092B, "ph"},
  {0x092C, "b"},
  {0x092D, "bh"},
  {0x092E, "m"},
  {0x092F, "y"},
  {0x0930, "r"},
  {0x0932, "l"},
  {0x0935, "v"},
  {0x0936, "ś"},
  {0x0937, "ṣ"},
  {0x0938, "s"},
  {0x0939, "h"},
  {0x095C, "ṛ"},
  {0x095D, "ṛh"},
  {0x0933, "ḷ"},
  {0x0958, "q"},
  {0x0959, "k͟h"},
  {0x095A, "ġ"},
  {0x095E, "f"},
  {0x095B, "z"},
  {0x0966, "0"},
  {0x0967, "1"},
  {0x0968, "2"},
  {0x0969, "3"},
  {0x096A, "4"},
  {0x096B, "5"},
  {0x096C, "6"},
  {0x096D, "7"},
  {0x096E, "8"},
  {0x096F, "9"}
};

int main(int argc, char *argv[]);
unsigned int getuch(FILE *infile);
void putuch(unsigned int uch);
int puttch(unsigned int dch);
int isinarray(unsigned int val, unsigned int *arr, int size);
int finddchar(unsigned int dch);

int main(int argc, char *argv[]) {
  unsigned int dch;
  if ((infile = fopen(argv[1], "rb")) == NULL) {
    fputs("Unable to open file\n", stderr);
    exit(1);
  }
  /*
   * Do the job
   */
  for ( ;; ) {
    dch = getuch(infile);
    if (dch == EOF) return(0);
    puttch(dch);
  }
  fclose(infile);
  exit(0);
}

/*
 * getuch: read a Unicode character
 */
unsigned int getuch(FILE *infile) {
  unsigned int uch, ch;
  uch = fgetc(infile);
  if (uch == EOF) return(EOF);
  if ((uch & 0x80) == 0) return(uch);
  else if ((uch & 0xE0) == 0xC0) {
    uch = (uch & 0x1F) << 6;
    ch = fgetc(infile);
    if (ch == EOF) return(EOF);
    uch |= (ch & 0x3F);
  }
  else {
    uch = (uch & 0x0F) << 12;
    ch = fgetc(infile);
    if (ch == EOF) return(EOF);
    uch |= (ch & 0x3F) << 6;
    ch = fgetc(infile);
    if (ch == EOF) return(EOF);
    uch |= (ch & 0x3F);
  }
  return(uch);
}

/*
 * putuch: write a Unicode character
 */
void putuch(unsigned int uch) {
  if (uch > 0x7FF) {
    fputc((unsigned char) (((uch >> 12) & 0xF) | 0xE0), stdout);
    fputc((unsigned char) (((uch >> 6) & 0x3F) | 0x80), stdout);
    fputc((unsigned char) ((uch & 0x3F) | 0x80), stdout);
    return;
  }
  if (uch > 0x7F) {
    fputc((unsigned char) (((uch >> 6) & 0x1F) | 0xC0), stdout);
    fputc((unsigned char) ((uch & 0x3F) | 0x80), stdout);
    return;
  }
  fputc((unsigned char) uch, stdout);
  return;
}

/*
 * puttch: write a Roman character
 */
int puttch(unsigned int dch) {
  int idx;
  unsigned char *tch;
  if (dch == HALANT) {
    consfound = 0;
    afound = 0;
    return(0);
  }
  if (afound && ((dch == 0x0907) || (dch == 0x0909))) {				/* Initial i, u */
    fputc(':', stdout);
    consfound = 0;
    afound =0;
  }
  idx = finddchar(dch);
  if (idx != -1) {
    tch = convlist[idx].tch;
    if ((consfound) && !(isinarray(dch, medvowel, MEDVOWELSIZE))) {
      fputc('a', stdout);
      afound = 1;
      if (afound && ((dch == 0x0907) || (dch == 0x0909))) {				/* Initial i, u */
	fputc(':', stdout);
	consfound = 0;
	afound =0;
      }
    }
    if (dch == 0x0905) afound = 1;								       	/* Initial a */
    else afound = 0;
    if (isinarray(dch, cons, CONSSIZE)) consfound = 1;
    else consfound = 0;
    fputs(tch, stdout);
    return(0);
  }
  if (consfound && !(isinarray(dch, medvowel, MEDVOWELSIZE))) {
    fputc('a', stdout);
  }
  putuch(dch);
  afound = 0;
  consfound = 0;
  return(0);
}

int isinarray(unsigned int val, unsigned int *arr, int size){
  int i;
  for (i = 0; i < size; i++) {
    if (arr[i] == val)
      return(1);
  }
  return(0);
}

int finddchar(unsigned int dch) {
  int i;
  for (i = 0; i < CONVLISTSIZE; i++) {
    if (convlist[i].dch == dch) {
      return(i);
    }
  }
  return(-1);
}

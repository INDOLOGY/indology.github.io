/*
 * uconv -- a program to convert between different Unicode representations
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined _WIN32
#include <fcntl.h>
#endif

#define MAXLINE 4096

int main(int argc, char *argv[]);
void process(FILE *infile);
int getwch(FILE *infile);
void putwch(int wch);

unsigned char ib, il, iu, ob, ol, ou;		/* Input/output endianness */
int queuedwch;
char *usage = "\
   Uconv converts between different Unicode representations, reading\n\
   from a file, or, if no filename is specified on the command line,\n\
   from standard input, and writing to standard output. The program can\n\
   accept as input UTF-8 and UCS-2 in both big-endian and little-endian\n\
   format, and its output can be in any of the same three forms. By\n\
   default, it attempts to determine the form of the input (by looking\n\
   for an initial 0xFFFE or 0xFEFF), and selects the same form for its\n\
   output. However, various command-line options can be used to force\n\
   different behaviour. The full set of options is as follows:\n\
      -il  --  input in little-endian UCS-2\n\
      -ib  --  input in big-endian UCS-2\n\
      -iu  --  input in UTF-8\n\
      -ol  --  output in little-endian UCS-2\n\
      -ob  --  output in big-endian UCS-2\n\
      -ou  --  output in UTF-8\n\
   The program does not check that UTF-8 input is syntactically valid:\n\
   invalid input will cause unpredictable results.\n\
";

int main(int argc, char *argv[]) {
   char infname[1024];
   FILE *infile;
   unsigned char i;
   /*
    * Kludge to get stdout opened in binary mode under Win32
    */
#if defined _WIN32
   setmode(fileno(stdout), _O_BINARY);
#endif 
   /*
    * Check switches
    */
   for (i = 1; i < argc && *argv[i] == '-'; i++) {
      if (strncmp(argv[i], "-ib", 4) == 0) {
	 ib = 1;
	 il = 0;
	 iu = 0;
      }
      else if (strncmp(argv[i], "-il", 4) == 0) {
	 ib = 0;
	 il = 1;
	 iu = 0;
      }
      else if (strncmp(argv[i], "-iu", 4) == 0) {
	 ib = 0;
	 il = 0;
	 iu = 1;
      }
      else if (strncmp(argv[i], "-ob", 4) == 0) {
	 ob = 1;
	 ol = 0;
	 ou = 0;
      }
      else if (strncmp(argv[i], "-ol", 4) == 0) {
	 ob = 0;
	 ol = 1;
	 ou = 0;
      }
      else if (strncmp(argv[i], "-ou", 4) == 0) {
	 ob = 0;
	 ol = 0;
	 ou = 1;
      }
      else {
	 fputs(usage, stderr);
	 exit(1);
      }
   }
   if (argc > i) {
      strcpy(infname, argv[i]);
      if ((infile = fopen(infname, "rb")) == NULL) {
	 fputs("Unable to open file\n", stderr);
	 exit(1);
      }
      process(infile);
      fclose(infile);
   }
   else process(stdin);
   exit(0);
}

/* process: do the job */
void process(FILE *infile) {
   int ch1, ch2, ch3, wch;
   /*
    * Check input for initial byte-order mark (0xFFEF/0xFFFE)
    */
   ch1 = getc(infile);
   if (ch1 == EOF) exit(0);
   ch2 = getc(infile);
   if (ch2 == EOF) exit(0);
   if ((ch1 == 0xFF) && (ch2 == 0xFE)) {	/* Detected little-endian */
      if (ib + il + iu == 0) {
	 ib = 0;
	 il = 1;
      }
   }
   else if ((ch1 == 0xFE) && (ch2 == 0xFF)) {	/* Detected big-endian */
      if (ib + il + iu == 0) {
	 ib = 1;
	 il = 0;
      }
   }
   /*
    * Non-detected formats
    */
   else if (il + ib == 0) {			/* UTF-8 */
      if ((ch1 & 0x80) == 0) {
	 queuedwch = ch1;
	 ungetc(ch2, infile);
      }
      else if ((ch1 & 0xE0) == 0xC0) {
	 queuedwch = (ch1 & 0x1F) << 6;
	 queuedwch |= (ch2 & 0x3F);
      }
      else {
	 queuedwch = (ch1 & 0x0F) << 12;
	 queuedwch |= (ch2 & 0x3F) << 6;
	 ch3 = getc(infile);
	 if (ch3 == EOF) exit(0);
	 queuedwch |= (ch3 & 0x3F);
      }
      if ((queuedwch == 0xFEFF) || (queuedwch == 0xFFFE)) queuedwch = 0;
   }
   else if (il == 1) queuedwch = ch1 | (ch2 << 8);
   else queuedwch = ch1 | ch2;
   /*
    * Initialise the output with 0xFEFF/0xFFFE if output is UCS-2
    */
   if (ob + ol + ou == 0) {
      ob = ib;
      ol = il;
   }
   if (ol == 1) {
      fputc(0xFF, stdout);
      fputc(0xFE, stdout);
   }
   else if (ob == 1) {
      fputc(0xFE, stdout);
      fputc(0xFF, stdout);
   }
   /*
    * Go!
    */
   for (;;) {
      wch = getwch(infile);
      if (wch == EOF) exit(0);
      putwch(wch);
   }
}

/* getwch: read a wide character */
int getwch(FILE *infile) {
   int wch, ch;
   if (queuedwch != 0) {
      wch = queuedwch;
      queuedwch = 0;
      return(wch);
   }
   if (il == 1) {			/* Little-endian UCS-2 input */
      wch = getc(infile);
      if (wch == EOF) return(EOF);
      ch = getc(infile);
      if (ch == EOF) return(EOF);
      wch = wch | (ch << 8);
      return(wch);
   }
   else if (ib == 1) {			/* Big-endian UCS-2 input */
      ch = getc(infile);
      if (ch == EOF) return(EOF);
      wch = ch << 8;
      ch = getc(infile);
      if (ch == EOF) return(EOF);
      wch = wch | ch;
      return(wch);
   }
   else {				/* UTF-8 input */
      wch = getc(infile);
      if (wch == EOF) return(EOF);
      if ((wch & 0x80) == 0) return(wch);
      else if ((wch & 0xE0) == 0xC0) {
	 wch = (wch & 0x1F) << 6;
	 ch = getc(infile);
	 if (ch == EOF) return(EOF);
	 wch |= (ch & 0x3F);
      }
      else {
	 wch = (wch & 0x0F) << 12;
	 ch = getc(infile);
	 if (ch == EOF) return(EOF);
	 wch |= (ch & 0x3F) << 6;
	 ch = getc(infile);
	 if (ch == EOF) return(EOF);
	 wch |= (ch & 0x3F);
      }
      return(wch);
   }
}

/* putwch: write a wide character */
void putwch(int wch) {
   if (ol == 1) {			/* Little-endian UCS-2 outnput */
      fputc((unsigned char)(wch), stdout);
      fputc((unsigned char)(wch >> 8), stdout);
   }
   else if (ob == 1) {			/* Big-endian UCS-2 output */
      fputc((unsigned char)(wch >> 8), stdout);
      fputc((unsigned char)(wch), stdout);
   }
   else {				/* UTF-8 output */
      if (wch > 0x7FF) {
	 fputc((unsigned char)(((wch >> 12) & 0xF) | 0xE0), stdout);
	 fputc((unsigned char)(((wch >> 6) & 0x3F) | 0x80), stdout);
	 fputc((unsigned char)((wch & 0x3F) | 0x80), stdout);
      }
      else {
	 if (wch > 0x7F) {
	    fputc((unsigned char)(((wch >> 6) & 0x1F) | 0xC0), stdout);
	    fputc((unsigned char)((wch & 0x3F) | 0x80), stdout);
	 }
	 else {
	    fputc((unsigned char)wch, stdout);
	 }
      }
   }
}

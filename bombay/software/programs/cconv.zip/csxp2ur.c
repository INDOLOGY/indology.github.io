/*
 * csxp2ur
 *
 * A program to convert Indian-language text from CSX+ to UTF-8
 * Unicode Roman.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXLINE 1000

int main(int argc, char *argv[]);
void process(FILE *infile);
int get_line(unsigned char line[MAXLINE], int max, FILE *infile);

/*
 * The first value in each convert[][] entry is the number of characters
 * to output. The sequence of entries is backwards in CSX+ terms,
 * to avoid having to start with 128 empty entries.
 */
unsigned short convert[128][5] = {
     {1, 0x1E24, 0, 0, 0},			/* H underdot */
     {1, 0x1E25, 0, 0, 0},			/* h underdot */
     {1, 0x1E42, 0, 0, 0},			/* M underdot */
     {1, 0x1E43, 0, 0, 0},			/* m underdot */
     {1, 0x201D, 0, 0, 0},			/* quotedblright */
     {1, 0x1E62, 0, 0, 0},			/* S underdot */
     {1, 0x1E63, 0, 0, 0},			/* s underdot */
     {1, 0x015A, 0, 0, 0},			/* S acute */
     {1, 0x015B, 0, 0, 0},			/* s acute */
     {1, 0x1E46, 0, 0, 0},			/* N underdot */
     {1, 0x1E47, 0, 0, 0},			/* n underdot */
     {1, 0x1E0C, 0, 0, 0},			/* D underdot */
     {1, 0x1E0D, 0, 0, 0},			/* d underdot */
     {1, 0x1E6C, 0, 0, 0},			/* T underdot */
     {1, 0x1E6D, 0, 0, 0},			/* t underdot */
     {1, 0x1E44, 0, 0, 0},			/* N overdot */
     {1, 0x1E45, 0, 0, 0},			/* n overdot */
     {1, 0x1E38, 0, 0, 0},			/* Lunderdot macron */
     {1, 0x1E39, 0, 0, 0},			/* lunderdot macron */
     {1, 0x1E36, 0, 0, 0},			/* L underdot */
     {1, 0x1E37, 0, 0, 0},			/* l underdot */
     {1, 0x1E5C, 0, 0, 0},			/* Runderdot macron */
     {1, 0x1E5D, 0, 0, 0},			/* runderdot macron */
     {1, 0x1E5A, 0, 0, 0},			/* R underdot */
     {1, 0x1E5B, 0, 0, 0},			/* r underdot */
     {1, 0x016A, 0, 0, 0},			/* U macron */
     {1, 0x016B, 0, 0, 0},			/* u macron */
     {1, 0x012A, 0, 0, 0},			/* I macron */
     {1, 0x012B, 0, 0, 0},			/* i macron */
     {1, 0x0100, 0, 0, 0},			/* A macron */
     {1, 0x00DF, 0, 0, 0},			/* germandbls */
     {1, 0x0101, 0, 0, 0},			/* a macron */
     {1, 0x201C, 0, 0, 0},			/* quotedblleft */
     {1, 0x2014, 0, 0, 0},			/* emdash */
     {1, 0x2013, 0, 0, 0},			/* endash */
     {1, 0x1E2B, 0, 0, 0},			/* h underbreve */
     {1, 0x1E96, 0, 0, 0},			/* h underbar */
     {1, 0x0108, 0, 0, 0},			/* C circumflex */
     {1, 0x0120, 0, 0, 0},			/* G overdot */
     {2, 0x016B, 0x0303, 0, 0},			/* umacron tilde */
     {1, 0x1E3B, 0, 0, 0},			/* l underbar */
     {1, 0x014F, 0, 0, 0},			/* o breve */
     {1, 0x0115, 0, 0, 0},			/* e breve */
     {1, 0x00F5, 0, 0, 0},			/* o tilde */
     {1, 0x1EBD, 0, 0, 0},			/* e tilde */
     {1, 0x0169, 0, 0, 0},			/* u tilde */
     {1, 0x0129, 0, 0, 0},			/* i tilde */
     {1, 0x00E3, 0, 0, 0},			/* a tilde */
     {2, 0x1E5D, 0x0301, 0, 0},			/* runderdotmacron acute */
     {1, 0x0109, 0, 0, 0},			/* c circumflex */
     {1, 0x0121, 0, 0, 0},			/* g overdot */
     {3, 0x006B, 0x035F, 0x0068, 0},		/* kh underbar */
     {1, 0x01E2, 0, 0, 0},			/* AE macron */
     {1, 0x00A0, 0, 0, 0},			/* Mac nbspace */
     {1, 0x1E35, 0, 0, 0},			/* k underbar */
     {3, 0x004B, 0x035F, 0x0068, 0},		/* Kh underbar */
     {2, 0x1E5B, 0x0300, 0, 0},			/* runderdot grave */
     {2, 0x1E5B, 0x0301, 0, 0},			/* runderdot acute */
     {2, 0x006E, 0x0306, 0, 0},			/* n breve */
     {1, 0x014C, 0, 0, 0},			/* O macron */
     {1, 0x0112, 0, 0, 0},			/* E macron */
     {1, 0x1E6F, 0, 0, 0},			/* t underbar */
     {2, 0x006D, 0x0310, 0, 0},			/* m candrabindu */
     {2, 0x014D, 0x0303, 0, 0},			/* omacron tilde */
     {2, 0x0072, 0x0306, 0, 0},			/* r breve */
     {2, 0x016B, 0x0300, 0, 0},			/* umacron grave */
     {2, 0x016B, 0x0301, 0, 0},			/* umacron acute */
     {1, 0x1E8F, 0, 0, 0},			/* y overdot */
     {2, 0x0052, 0x0325, 0, 0},			/* R underring */
     {1, 0x014D, 0, 0, 0},			/* o macron */
     {1, 0x0113, 0, 0, 0},			/* e macron */
     {2, 0x012B, 0x0300, 0, 0},			/* imacron grave */
     {2, 0x012B, 0x0301, 0, 0},			/* imacron acute */
     {2, 0x0101, 0x0300, 0, 0},			/* amacron grave */
     {2, 0x0101, 0x0301, 0, 0},			/* amacron acute */
     {2, 0x006D, 0x0306, 0, 0},			/* m breve */
     {4, 0x0072, 0x0325, 0x0304, 0x0301},	/* runderringmacron acute */
     {3, 0x0072, 0x0325, 0x0300, 0},		/* runderring grave */
     {3, 0x0072, 0x0325, 0x0301, 0},		/* runderring acute */
     {3, 0x006C, 0x0325, 0x0304, 0},		/* lunderring macron */
     {2, 0x006C, 0x0325, 0, 0},			/* l underring */
     {3, 0x0072, 0x0325, 0x0304, 0},		/* runderring macron */
     {1, 0x1E49, 0, 0, 0},			/* n underbar */
     {2, 0x012B, 0x0303, 0, 0},			/* imacron tilde */
     {2, 0x0101, 0x0303, 0, 0},			/* amacron tilde */
     {2, 0x016B, 0x0306, 0, 0},			/* umacron breve */
     {2, 0x012B, 0x0306, 0, 0},			/* imacron breve */
     {2, 0x0101, 0x0306, 0, 0},			/* amacron breve */
     {1, 0x1E41, 0, 0, 0},			/* m overdot */
     {2, 0x006C, 0x0303, 0, 0},			/* l tilde */
     {1, 0x00D1, 0, 0, 0},			/* N tilde */
     {1, 0x00F1, 0, 0, 0},			/* n tilde */
     {1, 0x00FA, 0, 0, 0},			/* u acute */
     {1, 0x00F3, 0, 0, 0},			/* o acute */
     {1, 0x00ED, 0, 0, 0},			/* i acute */
     {1, 0x00A0, 0, 0, 0},			/* PC nbspace */
     {1, 0x1E5F, 0, 0, 0},			/* r underbar */
     {1, 0x00E1, 0, 0, 0},			/* a acute */
     {2, 0x0072, 0x0325, 0, 0},			/* r underring */
     {2, 0x0113, 0x0303, 0, 0},			/* emacron tilde */
     {1, 0x016D, 0, 0, 0},			/* u breve */
     {1, 0x00DC, 0, 0, 0},			/* U dieresis */
     {1, 0x00D6, 0, 0, 0},			/* O dieresis */
     {1, 0x01E3, 0, 0, 0},			/* ae macron */
     {1, 0x00F9, 0, 0, 0},			/* u grave */
     {1, 0x00FB, 0, 0, 0},			/* u circumflex */
     {1, 0x00F2, 0, 0, 0},			/* o grave */
     {1, 0x00F6, 0, 0, 0},			/* o dieresis */
     {1, 0x00F4, 0, 0, 0},			/* o circumflex */
     {1, 0x00C6, 0, 0, 0},			/* AE */
     {1, 0x00E6, 0, 0, 0},			/* ae */
     {1, 0x00C9, 0, 0, 0},			/* E acute */
     {1, 0x00C5, 0, 0, 0},			/* A ring */
     {1, 0x00C4, 0, 0, 0},			/* A dieresis */
     {1, 0x00EC, 0, 0, 0},			/* i grave */
     {1, 0x00EE, 0, 0, 0},			/* i circumflex */
     {1, 0x00EF, 0, 0, 0},			/* i dieresis */
     {1, 0x00E8, 0, 0, 0},			/* e grave */
     {1, 0x00EB, 0, 0, 0},			/* e dieresis */
     {1, 0x00EA, 0, 0, 0},			/* e circumflex */
     {1, 0x00E7, 0, 0, 0},			/* c cedilla */
     {1, 0x00E5, 0, 0, 0},			/* a ring */
     {1, 0x00E0, 0, 0, 0},			/* a grave */
     {1, 0x00E4, 0, 0, 0},			/* a dieresis */
     {1, 0x00E2, 0, 0, 0},			/* a circumflex */
     {1, 0x00E9, 0, 0, 0},			/* e acute */
     {1, 0x00FC, 0, 0, 0},			/* u dieresis */
     {1, 0x00C7, 0, 0, 0}			/* C cedilla */
};

int main(int argc, char *argv[]) {
   char infname[128];
   FILE *infile;
   if (argc > 1) {
      strcpy(infname, argv[1]);
      if ((infile = fopen(infname, "r")) == NULL) {
	 fputs("\nUnable to open file\n", stderr);
	 exit(1);
      }
      process(infile);
      fclose(infile);
   }
   else process(stdin);
   exit(0);
}

/* process: do the job */
void process(FILE *infile) {
   unsigned short i, len, ch;
   unsigned char line[MAXLINE], j, k;
   while ((len = get_line(line, MAXLINE, infile)) > 0) {
      for (i = 0; i < len; i++) {
	 if (line[i] == '\'') {	/* convert ASCII apsotrophe to U+2019 */
	    fputc(0xE2, stdout);
	    fputc(0x80, stdout);
	    fputc(0x99, stdout);
	 }
	 else if (line[i] < 0x80) {
	    fputc(line[i], stdout);
	 }
	 else {
	    k = ~(line[i]);
	    for (j = 1; j <= convert[k][0]; j++) {
	       ch = convert[k][j];
	       if (ch > 0x7FF) {
		  fputc((unsigned char)(((ch >> 12) & 0xF) | 0xE0), stdout);
		  fputc((unsigned char)(((ch >> 6) & 0x3F) | 0x80), stdout);
		  fputc((unsigned char)((ch & 0x3F) | 0x80), stdout);
	       }
	       else {
		  if (ch > 0x7F) {
		     fputc((unsigned char)(((ch >> 6) & 0x1F) | 0xC0), stdout);
		     fputc((unsigned char)((ch & 0x3F) | 0x80), stdout);
		  }
		  else {
		     fputc((unsigned char)ch, stdout);
		  }
	       }
	    }
	 }
      }
   }
}

/* get_line: read a line, return length */
int get_line(unsigned char line[MAXLINE], int max, FILE *infile) {
   if (fgets(line, max, infile) == NULL) return 0;
   else return strlen(line);
}

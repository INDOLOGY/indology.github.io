/*
 * ur2ud -- a program to convert text from Unicode Roman (following
 * ISO 15919 conventions) to Unicode Devanagari.
 *
 * Copyright John D. Smith, University of Cambridge, 2002. Email
 * jds10@cam.ac.uk
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*
 * N.b.: it should be relatively simple to modify this program to
 * handle other Indian scripts by changing the values stored in
 * convlist[] and numlist[] (and probably also the housekeeping
 * tasks done in putdch() before the bulk lookup-and-output begins).
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined _WIN32
#include <fcntl.h>
#endif

#define TSIZE 5				/* size of transliteration chars */
					/* (null terminated) */
#define DSIZE 3				/* size of Devanagari chars */
					/* (null terminated) */
#define CONVLISTSIZE (sizeof convlist / sizeof convlist[0])

/*
 * values used for sylstate (CONS also used in ur2ud structs)
 */
#define NEW   -1			/* prior syllable complete */
#define CONS  -2			/* consonant pending in syllable */
#define OTHER -3			/* previous char not Devanagari */

#define HALANT   0x094D
#define AVAGRAHA 0x093D
#define APOSTR   0x2019
#define igrave   0x00EC
#define iacute   0x00ED
#define itilde   0x0129
#define Igrave   0x00CC
#define Iacute   0x00CD
#define Itilde   0x0128
#define ugrave   0x00F9
#define uacute   0x00FA
#define utilde   0x0169
#define Ugrave   0x00D9
#define Uacute   0x00DA
#define Utilde   0x0168
#define tdot     0x1E6D
#define Tdot     0x1E6C
#define ddot     0x1E0D
#define Ddot     0x1E0C
#define rdot     0x1E5B
#define Rdot     0x1E5A
#define mdot     0x1E41
#define Mdot     0x1E40

unsigned char ib, il, iu, ob, ol, ou, dnnum, skt;	/* switch variables */
FILE *infile;
int queueduch;
int queuedtch[TSIZE];
int sylstate = NEW;

int main(int argc, char *argv[]);
void process(FILE *infile);
int getuch(FILE *infile);
void putuch(int uch);
void gettch(FILE *infile, int tch[]);
int putdch (FILE *infile, int *tchptr);
int lcharcmp(int *ch1, int *ch2);
int *lchardup(int *uch, unsigned char size);
struct ur2ud *lookup(int *tchptr);
struct ur2ud *install(int *tch, int *dch1, int *dch2);

char *usage = "\
   Ur2ud converts from Unicode Roman (following the transliteration\n\
   standard specified by ISO 15919) to Unicode Devanagari. It reads\n\
   from a file, or, if no filename is specified on the command line,\n\
   from standard input, and writes to standard output. The program can\n\
   accept as input UTF-8 and UCS-2/UTF-16 in both big-endian and\n\
   little-endian format, and its output can be in any of the same three\n\
   forms. By default, it attempts to determine the form of the input\n\
   (by looking for an initial 0xFFFE or 0xFEFF), and selects the same\n\
   form for its output. However, various command-line options can be\n\
   used to force different behaviour. The full set of options is as\n\
   follows:\n\
      -il  --  input in little-endian UCS-2\n\
      -ib  --  input in big-endian UCS-2\n\
      -iu  --  input in UTF-8\n\
      -ol  --  output in little-endian UCS-2\n\
      -ob  --  output in big-endian UCS-2\n\
      -ou  --  output in UTF-8\n\
      -n   --  convert numerals to Devanagari\n\
      -s   --  text is Sanskrit: handle space and avagraha characters\n\
               appropriately\n\
   The program does not check that input is valid in terms of ISO 15919,\n\
   or that UTF-8 input is syntactically valid. Invalid input will cause\n\
   unpredictable results. Accented (Vedic) Roman input using acute and\n\
   grave accents over vowels will produce correct but unaccented\n\
   Devanagari output (the underscore notation for anudatta vowels is\n\
   not currently supported, since it is not clear what its Unicode\n\
   representation should be).\n\
";

/*
 * ur2ud defines a struct containing the following items:
 * 1. A pointer to the next such struct in the linked list;
 * 2. A transliteration character tch;
 * 3. A Devanagari character dch1, which will replace tch when a
 *    new syllable is being started;
 * 4. A Devanagari character dch2, which will replace tch when the
 *    current syllable already contains a consonant -- typically
 *    a matra vowel. Consonant tch characters have the special value
 *    CONS in dch2, indicating that the replacement should be halant
 *    followed by dch1.
 */
struct ur2ud {
   struct ur2ud *next;
   int *tch;
   int *dch1;
   int *dch2;
};

/*
 * convtab[] is the conversion table. It is indexed according to the
 * least significant byte of the first character of each tch, so that
 * ASCII and ISO-Latin 1 values will be in their "natural" places;
 * other values are not numerous or "bunched" enough to cause
 * problems.
 */
struct ur2ud *convtab[256];

/*
 * convinfo defines a struct containing the values needed by a ur2ud
 * struct. The array convlist[] is used by install() to initialise the
 * convtab[] table.
 */
struct convinfo {
   int tch[TSIZE];
   int dch1[DSIZE];
   int dch2[DSIZE];
};

struct convinfo convlist[] = {
   /*
    * ASCII chars
    */
     {{'a', 0}, {0x0905, 0}, {0, 0}},
     {{'A', 0}, {0x0905, 0}, {0, 0}},
     {{'i', 0}, {0x0907, 0}, {0x093F, 0}},
     {{'I', 0}, {0x0907, 0}, {0x093F, 0}},
     {{'u', 0}, {0x0909, 0}, {0x0941, 0}},
     {{'U', 0}, {0x0909, 0}, {0x0941, 0}},
     {{'e', 0}, {0x090F, 0}, {0x0947, 0}},
     {{'E', 0}, {0x090F, 0}, {0x0947, 0}},
     {{'o', 0}, {0x0913, 0}, {0x094B, 0}},
     {{'O', 0}, {0x0913, 0}, {0x094B, 0}},
     {{'a', 'i', 0}, {0x0910, 0}, {0x0948, 0}},
     {{'A', 'i', 0}, {0x0910, 0}, {0x0948, 0}},
     {{'a', 'u', 0}, {0x0914, 0}, {0x094C, 0}},
     {{'A', 'u', 0}, {0x0914, 0}, {0x094C, 0}},
     {{'k', 0}, {0x0915, 0}, {CONS, 0}},
     {{'K', 0}, {0x0915, 0}, {CONS, 0}},
     {{'q', 0}, {0x0958, 0}, {CONS, 0}},
     {{'Q', 0}, {0x0958, 0}, {CONS, 0}},
     {{'k', 'h', 0}, {0x0916, 0}, {CONS, 0}},
     {{'K', 'h', 0}, {0x0916, 0}, {CONS, 0}},
     {{'g', 0}, {0x0917, 0}, {CONS, 0}},
     {{'G', 0}, {0x0917, 0}, {CONS, 0}},
     {{'g', 'h', 0}, {0x0918, 0}, {CONS, 0}},
     {{'G', 'h', 0}, {0x0918, 0}, {CONS, 0}},
     {{'c', 0}, {0x091A, 0}, {CONS, 0}},
     {{'C', 0}, {0x091A, 0}, {CONS, 0}},
     {{'c', 'h', 0}, {0x091B, 0}, {CONS, 0}},
     {{'C', 'h', 0}, {0x091B, 0}, {CONS, 0}},
     {{'j', 0}, {0x091C, 0}, {CONS, 0}},
     {{'J', 0}, {0x091C, 0}, {CONS, 0}},
     {{'z', 0}, {0x095B, 0}, {CONS, 0}},
     {{'Z', 0}, {0x095B, 0}, {CONS, 0}},
     {{'j', 'h', 0}, {0x091D, 0}, {CONS, 0}},
     {{'J', 'h', 0}, {0x091D, 0}, {CONS, 0}},
     {{'t', 0}, {0x0924, 0}, {CONS, 0}},
     {{'T', 0}, {0x0924, 0}, {CONS, 0}},
     {{'t', 'h', 0}, {0x0925, 0}, {CONS, 0}},
     {{'T', 'h', 0}, {0x0925, 0}, {CONS, 0}},
     {{'d', 0}, {0x0926, 0}, {CONS, 0}},
     {{'D', 0}, {0x0926, 0}, {CONS, 0}},
     {{'d', 'h', 0}, {0x0927, 0}, {CONS, 0}},
     {{'D', 'h', 0}, {0x0927, 0}, {CONS, 0}},
     {{'n', 0}, {0x0928, 0}, {CONS, 0}},
     {{'N', 0}, {0x0928, 0}, {CONS, 0}},
     {{'p', 0}, {0x092A, 0}, {CONS, 0}},
     {{'P', 0}, {0x092A, 0}, {CONS, 0}},
     {{'p', 'h', 0}, {0x092B, 0}, {CONS, 0}},
     {{'P', 'h', 0}, {0x092B, 0}, {CONS, 0}},
     {{'f', 0}, {0x095E, 0}, {CONS, 0}},
     {{'F', 0}, {0x095E, 0}, {CONS, 0}},
     {{'b', 0}, {0x092C, 0}, {CONS, 0}},
     {{'B', 0}, {0x092C, 0}, {CONS, 0}},
     {{'b', 'h', 0}, {0x092D, 0}, {CONS, 0}},
     {{'B', 'h', 0}, {0x092D, 0}, {CONS, 0}},
     {{'m', 0}, {0x092E, 0}, {CONS, 0}},
     {{'M', 0}, {0x092E, 0}, {CONS, 0}},
     {{'y', 0}, {0x092F, 0}, {CONS, 0}},
     {{'Y', 0}, {0x092F, 0}, {CONS, 0}},
     {{'r', 0}, {0x0930, 0}, {CONS, 0}},
     {{'R', 0}, {0x0930, 0}, {CONS, 0}},
     {{'l', 0}, {0x0932, 0}, {CONS, 0}},
     {{'L', 0}, {0x0932, 0}, {CONS, 0}},
     {{'v', 0}, {0x0935, 0}, {CONS, 0}},
     {{'V', 0}, {0x0935, 0}, {CONS, 0}},
     {{'s', 0}, {0x0938, 0}, {CONS, 0}},
     {{'S', 0}, {0x0938, 0}, {CONS, 0}},
     {{'h', 0}, {0x0939, 0}, {CONS, 0}},
     {{'H', 0}, {0x0939, 0}, {CONS, 0}},
   /*
    * ISO-Latin 1 chars
    */
     {{0x00E0, 0}, {0x0905, 0}, {0, 0}},			/* a grave */
     {{0x00C0, 0}, {0x0905, 0}, {0, 0}},			/* A grave */
     {{0x00E1, 0}, {0x0905, 0}, {0, 0}},			/* a acute */
     {{0x00C1, 0}, {0x0905, 0}, {0, 0}},			/* A acute */
     {{0x00EC, 0}, {0x0907, 0}, {0x093F, 0}},			/* i grave */
     {{0x00CC, 0}, {0x0907, 0}, {0x093F, 0}},			/* I grave */
     {{0x00ED, 0}, {0x0907, 0}, {0x093F, 0}},			/* i acute */
     {{0x00CD, 0}, {0x0907, 0}, {0x093F, 0}},			/* I acute */
     {{0x00F9, 0}, {0x0909, 0}, {0x0941, 0}},			/* u grave */
     {{0x00D9, 0}, {0x0909, 0}, {0x0941, 0}},			/* U grave */
     {{0x00FA, 0}, {0x0909, 0}, {0x0941, 0}},			/* u acute */
     {{0x00DA, 0}, {0x0909, 0}, {0x0941, 0}},			/* U acute */
     {{0x00E8, 0}, {0x090F, 0}, {0x0947, 0}},			/* e grave */
     {{0x00C8, 0}, {0x090F, 0}, {0x0947, 0}},			/* E grave */
     {{0x00E9, 0}, {0x090F, 0}, {0x0947, 0}},			/* e acute */
     {{0x00C9, 0}, {0x090F, 0}, {0x0947, 0}},			/* E acute */
     {{0x00F2, 0}, {0x0913, 0}, {0x094B, 0}},			/* o grave */
     {{0x00D2, 0}, {0x0913, 0}, {0x094B, 0}},			/* O grave */
     {{0x00F3, 0}, {0x0913, 0}, {0x094B, 0}},			/* o acute */
     {{0x00D3, 0}, {0x0913, 0}, {0x094B, 0}},			/* O acute */
     {{0x00EA, 0}, {0x090D, 0}, {0x0945, 0}},			/* e circ */
     {{0x00CA, 0}, {0x090D, 0}, {0x0945, 0}},			/* E circ */
     {{0x00F4, 0}, {0x0911, 0}, {0x0949, 0}},			/* o circ */
     {{0x00D4, 0}, {0x0911, 0}, {0x0949, 0}},			/* O circ */
     {{0x00E3, 0}, {0x0905, 0x0901, 0}, {0x0901, 0}},		/* a tilde */
     {{0x00C3, 0}, {0x0905, 0x0901, 0}, {0x0901, 0}},		/* A tilde */
     {{0x00F5, 0}, {0x0913, 0x0902, 0}, {0x094B, 0x0902, 0}},	/* o tilde */
     {{0x00D5, 0}, {0x0913, 0x0902, 0}, {0x094B, 0x0902, 0}},	/* O tilde */
     {{0x00F1, 0}, {0x091E, 0}, {CONS, 0}},			/* n tilde */
     {{0x00D1, 0}, {0x091E, 0}, {CONS, 0}},			/* N tilde */
   /*
    * Other single-codepoint chars
    */
     {{0x0101, 0}, {0x0906, 0}, {0x093E, 0}},			/* a macron */
     {{0x0100, 0}, {0x0906, 0}, {0x093E, 0}},			/* A macron */
     {{0x1EBD, 0}, {0x090F, 0x0901, 0}, {0x0947, 0x0902, 0}},	/* e tilde */
     {{0x1EBC, 0}, {0x090F, 0x0901, 0}, {0x0947, 0x0902, 0}},	/* E tilde */
     {{0x012B, 0}, {0x0908, 0}, {0x0940, 0}},			/* i macron */
     {{0x012A, 0}, {0x0908, 0}, {0x0940, 0}},			/* I macron */
     {{0x016B, 0}, {0x090A, 0}, {0x0942, 0}},			/* u macron */
     {{0x016A, 0}, {0x090A, 0}, {0x0942, 0}},			/* U macron */
     {{0x0129, 0}, {0x0907, 0x0901, 0}, {0x093F, 0x0902, 0}},	/* i tilde */
     {{0x0128, 0}, {0x0907, 0x0901, 0}, {0x093F, 0x0902, 0}},	/* I tilde */
     {{0x0169, 0}, {0x0909, 0x0901, 0}, {0x0941, 0x0901, 0}},	/* u tilde */
     {{0x0168, 0}, {0x0909, 0x0901, 0}, {0x0941, 0x0901, 0}},	/* U tilde */
     {{0x1E41, 0}, {0x0902, 0}, {0, 0}},			/* m odot*/
     {{0x1E40, 0}, {0x0902, 0}, {0, 0}},			/* M odot*/
     {{0x1E25, 0}, {0x0903, 0}, {0, 0}},			/* h udot*/
     {{0x1E24, 0}, {0x0903, 0}, {0, 0}},			/* H udot*/
   /* h ubar: no Unicode Devanagari char */
   /* h ubreve: no Unicode Devanagari char */
   /* H ubreve: no Unicode Devanagari char */
     {{0x0121, 0}, {0x095A, 0}, {CONS, 0}},			/* g odot */
     {{0x0120, 0}, {0x095A, 0}, {CONS, 0}},			/* G odot */
     {{0x1E45, 0}, {0x0919, 0}, {CONS, 0}},			/* n odot*/
     {{0x1E44, 0}, {0x0919, 0}, {CONS, 0}},			/* N odot*/
     {{0x1E6D, 0}, {0x091F, 0}, {CONS, 0}},			/* t udot*/
     {{0x1E6C, 0}, {0x091F, 0}, {CONS, 0}},			/* T udot*/
     {{0x1E6D, 'h', 0}, {0x0920, 0}, {CONS, 0}},		/* th udot*/
     {{0x1E6C, 'h', 0}, {0x0920, 0}, {CONS, 0}},		/* Th udot*/
     {{0x1E0D, 0}, {0x0921, 0}, {CONS, 0}},			/* d udot*/
     {{0x1E0C, 0}, {0x0921, 0}, {CONS, 0}},			/* D udot*/
     {{0x1E0D, 'h', 0}, {0x0922, 0}, {CONS, 0}},		/* dh udot*/
     {{0x1E0C, 'h', 0}, {0x0922, 0}, {CONS, 0}},		/* Dh udot*/
     {{0x1E5B, 0}, {0x095C, 0}, {CONS, 0}},			/* r udot*/
     {{0x1E5A, 0}, {0x095C, 0}, {CONS, 0}},			/* R udot*/
     {{0x1E5B, 'h', 0}, {0x095D, 0}, {CONS, 0}},		/* rh udot*/
     {{0x1E5A, 'h', 0}, {0x095D, 0}, {CONS, 0}},		/* Rh udot*/
     {{0x1E47, 0}, {0x0923, 0}, {CONS, 0}},			/* n udot*/
     {{0x1E46, 0}, {0x0923, 0}, {CONS, 0}},			/* N udot*/
     {{0x1E49, 0}, {0x0929, 0}, {CONS, 0}},			/* n ubar */
     {{0x1E48, 0}, {0x0929, 0}, {CONS, 0}},			/* N ubar */
     {{0x1E37, 0}, {0x0933, 0}, {CONS, 0}},			/* l udot*/
     {{0x1E36, 0}, {0x0933, 0}, {CONS, 0}},			/* L udot*/
     {{0x1E3B, 0}, {0x0934, 0}, {CONS, 0}},			/* l ubar */
     {{0x1E3A, 0}, {0x0934, 0}, {CONS, 0}},			/* L ubar */
     {{0x015B, 0}, {0x0936, 0}, {CONS, 0}},			/* s acute*/
     {{0x015A, 0}, {0x0936, 0}, {CONS, 0}},			/* S acute*/
     {{0x1E63, 0}, {0x0937, 0}, {CONS, 0}},			/* s udot*/
     {{0x1E62, 0}, {0x0937, 0}, {CONS, 0}},			/* S udot*/
     {{0x1E8F, 0}, {0x095F, 0}, {CONS, 0}},			/* y odot */
     {{0x1E8E, 0}, {0x095F, 0}, {CONS, 0}},			/* Y odot */
   /*
    * Two-codepoint chars
    */
     {{'a', 0x0129, 0}, {0x0910, 0x0902, 0}, {0x0948, 0x0902, 0}},
   								/* ai tilde */
     {{'A', 0x0129, 0}, {0x0910, 0x0902, 0}, {0x0948, 0x0902, 0}},
   								/* Ai tilde */
     {{'a', 0x0169, 0}, {0x0914, 0x0902, 0}, {0x094C, 0x0902, 0}},
   								/* au tilde */
     {{'A', 0x0169, 0}, {0x0914, 0x0902, 0}, {0x094C, 0x0902, 0}},
   								/* Au tilde */
     {{0x0101, 0x0303, 0}, {0x0906, 0x0901, 0}, {0x093E, 0x0901, 0}},
								/* a mactil */
     {{0x0100, 0x0303, 0}, {0x0906, 0x0901, 0}, {0x093E, 0x0901, 0}},
								/* A mactil */
     {{0x012B, 0x0303, 0}, {0x0908, 0x0902, 0}, {0x0940, 0x0902, 0}},
								/* i mactil */
     {{0x012A, 0x0303, 0}, {0x0908, 0x0902, 0}, {0x0940, 0x0902, 0}},
								/* I mactil */
     {{0x016B, 0x0303, 0}, {0x090A, 0x0901, 0}, {0x0942, 0x0901, 0}},
								/* u mactil */
     {{0x016A, 0x0303, 0}, {0x090A, 0x0901, 0}, {0x0942, 0x0901, 0}},
								/* U mactil */
     {{0x0101, 0x0300, 0}, {0x0906, 0}, {0x093E, 0}},		/* a macgrv */
     {{0x0100, 0x0300, 0}, {0x0906, 0}, {0x093E, 0}},		/* A macgrv */
     {{0x0101, 0x0301, 0}, {0x0906, 0}, {0x093E, 0}},		/* a macac */
     {{0x0100, 0x0301, 0}, {0x0906, 0}, {0x093E, 0}},		/* A macac */
     {{0x012B, 0x0300, 0}, {0x0908, 0}, {0x0940, 0}},		/* i macgrv */
     {{0x012A, 0x0300, 0}, {0x0908, 0}, {0x0940, 0}},		/* I macgrv */
     {{0x012B, 0x0301, 0}, {0x0908, 0}, {0x0940, 0}},		/* i macac */
     {{0x012A, 0x0301, 0}, {0x0908, 0}, {0x0940, 0}},		/* I macac */
     {{0x016B, 0x0300, 0}, {0x090A, 0}, {0x0942, 0}},		/* u macgrv */
     {{0x016A, 0x0300, 0}, {0x090A, 0}, {0x0942, 0}},		/* U macgrv */
     {{0x016B, 0x0301, 0}, {0x090A, 0}, {0x0942, 0}},		/* u macac */
     {{0x016A, 0x0301, 0}, {0x090A, 0}, {0x0942, 0}},		/* U macac */
     {{'l', 0x0325, 0}, {0x090C, 0}, {0x0962, 0}},		/* l uring */
     {{'L', 0x0325, 0}, {0x090C, 0}, {0x0962, 0}},		/* L uring */
     {{'r', 0x0325, 0}, {0x090B, 0}, {0x0943, 0}},		/* r uring */
     {{'R', 0x0325, 0}, {0x090B, 0}, {0x0943, 0}},		/* R uring */
     {{'m', 0x0310, 0}, {0x0901, 0}, {0, 0}},			/* m cand */
     {{'M', 0x0310, 0}, {0x0901, 0}, {0, 0}},			/* M cand */
   /* H ubar: no Unicode Devanagari char */
     {{'r', 0x0306, 0}, {0x0931, 0}, {CONS, 0}},		/* r breve */
     {{'R', 0x0306, 0}, {0x0931, 0}, {CONS, 0}},		/* R breve */
   /*
    * Three-codepoint chars
    */
     {{'l', 0x0325, 0x0304, 0}, {0x0961, 0}, {0x0963, 0}},    /* l uringmac */
     {{'L', 0x0325, 0x0304, 0}, {0x0961, 0}, {0x0963, 0}},    /* L uringmac */
     {{'r', 0x0325, 0x0304, 0}, {0x0960, 0}, {0x0944, 0}},    /* r uringmac */
     {{'R', 0x0325, 0x0304, 0}, {0x0960, 0}, {0x0944, 0}},    /* R uringmac */
     {{'l', 0x0325, 0x0300, 0}, {0x090C, 0}, {0x0962, 0}},    /* l uringgrv */
     {{'L', 0x0325, 0x0300, 0}, {0x090C, 0}, {0x0962, 0}},    /* L uringgrv */
     {{'l', 0x0325, 0x0301, 0}, {0x090C, 0}, {0x0962, 0}},    /* l uringac */
     {{'L', 0x0325, 0x0301, 0}, {0x090C, 0}, {0x0962, 0}},    /* L uringac */
     {{'r', 0x0325, 0x0300, 0}, {0x090B, 0}, {0x0943, 0}},    /* r uringgrv */
     {{'R', 0x0325, 0x0300, 0}, {0x090B, 0}, {0x0943, 0}},    /* R uringgrv */
     {{'r', 0x0325, 0x0301, 0}, {0x090B, 0}, {0x0943, 0}},    /* r uringac */
     {{'R', 0x0325, 0x0301, 0}, {0x090B, 0}, {0x0943, 0}},    /* R uringac */
     {{'k', 0x035F, 'h', 0}, {0x0959, 0}, {CONS, 0}},	      /* kh ubar */
     {{'K', 0x035F, 'h', 0}, {0x0959, 0}, {CONS, 0}},	      /* Kh ubar */
     {{'k', 0x035F, 'H', 0}, {0x0959, 0}, {CONS, 0}},	      /* kH ubar */
     {{'K', 0x035F, 'H', 0}, {0x0959, 0}, {CONS, 0}},	      /* KH ubar */
   /*
    * Four-codepoint chars
    */
     {{'l', 0x0325, 0x0304, 0x0300, 0}, {0x0961, 0}, {0x0963, 0}},
							    /* l uringmacgrv */
     {{'L', 0x0325, 0x0304, 0x0300, 0}, {0x0961, 0}, {0x0963, 0}},
							    /* L uringmacgrv */
     {{'l', 0x0325, 0x0304, 0x0301, 0}, {0x0961, 0}, {0x0963, 0}},
							    /* l uringmacac */
     {{'L', 0x0325, 0x0304, 0x0301, 0}, {0x0961, 0}, {0x0963, 0}},
							    /* L uringmacac */
     {{'r', 0x0325, 0x0304, 0x0300, 0}, {0x0960, 0}, {0x0944, 0}},
							    /* r uringmacgrv */
     {{'R', 0x0325, 0x0304, 0x0300, 0}, {0x0960, 0}, {0x0944, 0}},
							    /* R uringmacgrv */
     {{'r', 0x0325, 0x0304, 0x0301, 0}, {0x0960, 0}, {0x0944, 0}},
							    /* r uringmacac */
     {{'R', 0x0325, 0x0304, 0x0301, 0}, {0x0960, 0}, {0x0944, 0}},
							    /* R uringmacac */
};

/*
 * Convert numerals to Devanagari
 */
struct convinfo numlist[] = {
     {{'0', 0}, {0x0966, 0}, {HALANT, 0x0966, 0}},
     {{'1', 0}, {0x0967, 0}, {HALANT, 0x0967, 0}},
     {{'2', 0}, {0x0968, 0}, {HALANT, 0x0968, 0}},
     {{'3', 0}, {0x0969, 0}, {HALANT, 0x0969, 0}},
     {{'4', 0}, {0x096A, 0}, {HALANT, 0x096A, 0}},
     {{'5', 0}, {0x096B, 0}, {HALANT, 0x096B, 0}},
     {{'6', 0}, {0x096C, 0}, {HALANT, 0x096C, 0}},
     {{'7', 0}, {0x096D, 0}, {HALANT, 0x096D, 0}},
     {{'8', 0}, {0x096E, 0}, {HALANT, 0x096E, 0}},
     {{'9', 0}, {0x096F, 0}, {HALANT, 0x096F, 0}},
};

/*
 * Convert apostrophe to avagraha
 */
struct convinfo avagraha[] = {
     {{'\'', 0}, {AVAGRAHA, 0}, {0, 0}},
     {{APOSTR, 0}, {AVAGRAHA, 0}, {0, 0}},	/* approved apostrophe */
};

int main(int argc, char *argv[]) {
   unsigned short i, j;
   /*
    * Kludge to get stdout opened in binary mode under Win32
    */
#if defined _WIN32
   setmode(fileno(stdout), _O_BINARY);
#endif 
   /*
    * Check switches
    */
   for (i = 1; i < argc && *argv[i] == '-'; i++) {
      if (strncmp(argv[i], "-ib", 4) == 0) {
	 ib = 1;
	 il = 0;
	 iu = 0;
      }
      else if (strncmp(argv[i], "-il", 4) == 0) {
	 ib = 0;
	 il = 1;
	 iu = 0;
      }
      else if (strncmp(argv[i], "-iu", 4) == 0) {
	 ib = 0;
	 il = 0;
	 iu = 1;
      }
      else if (strncmp(argv[i], "-ob", 4) == 0) {
	 ob = 1;
	 ol = 0;
	 ou = 0;
      }
      else if (strncmp(argv[i], "-ol", 4) == 0) {
	 ob = 0;
	 ol = 1;
	 ou = 0;
      }
      else if (strncmp(argv[i], "-ou", 4) == 0) {
	 ob = 0;
	 ol = 0;
	 ou = 1;
      }
      else if (strncmp(argv[i], "-n", 3) == 0) dnnum = 1;
      else if (strncmp(argv[i], "-s", 3) == 0) skt = 1;
      else {
	 fputs(usage, stderr);
	 exit(1);
      }
   }
   /*
    * Initialise the conversion table
    */
   for (j = 0; j < CONVLISTSIZE; j++)
     install(convlist[j].tch, convlist[j].dch1, convlist[j].dch2);
   if (dnnum == 1)
     for (j = 0; j < 10; j++)
       install(numlist[j].tch, numlist[j].dch1, numlist[j].dch2);
   if (skt == 1)
     for (j = 0; j < 2; j++)
       install (avagraha[j].tch, avagraha[j].dch1, avagraha[j].dch2);
   if (argc > i) {
      if ((infile = fopen(argv[i], "rb")) == NULL) {
	 fputs("Unable to open file\n", stderr);
	 exit(1);
      }
      process(infile);
      fclose(infile);
   }
   else process(stdin);
   exit(0);
}

/*
 * process: do the job
 */
void process(FILE *infile) {
   int ch1, ch2, ch3;
   int tch[TSIZE];
   /*
    * Check input for initial byte-order mark (0xFEFF/0xFFFE)
    */
   ch1 = getc(infile);
   if (ch1 == EOF) exit(0);
   ch2 = getc(infile);
   if ((ch1 == 0xFF) && (ch2 == 0xFE)) {	/* Detected little-endian */
      if (ib + il + iu == 0) {
	 ib = 0;
	 il = 1;
      }
   }
   else if ((ch1 == 0xFE) && (ch2 == 0xFF)) {	/* Detected big-endian */
      if (ib + il + iu == 0) {
	 ib = 1;
	 il = 0;
      }
   }
   /*
    * Non-detected formats
    */
   else if (il + ib == 0) {			/* UTF-8 */
      if ((ch1 & 0x80) == 0) {
	 queueduch = ch1;
	 ungetc(ch2, infile);
      }
      else if ((ch1 & 0xE0) == 0xC0) {
	 queueduch = (ch1 & 0x1F) << 6;
	 queueduch |= (ch2 & 0x3F);
      }
      else {
	 queueduch = (ch1 & 0x0F) << 12;
	 queueduch |= (ch2 & 0x3F) << 6;
	 ch3 = getc(infile);
	 if (ch3 == EOF) exit(0);		/* 1st input char malformed */
	 queueduch |= (ch3 & 0x3F);
      }
      if ((queueduch == 0xFEFF) || (queueduch == 0xFFFE)) queueduch = 0;
   }
   else if (il == 1) queueduch = ch1 | (ch2 << 8);
   else queueduch = ch1 | ch2;
   /*
    * Initialise the output with 0xFEFF/0xFFFE if output is UCS-2
    */
   if (ob + ol + ou == 0) {
      ob = ib;
      ol = il;
   }
   if (ol == 1) {
      fputc(0xFF, stdout);
      fputc(0xFE, stdout);
   }
   else if (ob == 1) {
      fputc(0xFE, stdout);
      fputc(0xFF, stdout);
   }
   /*
    * Go!
    */
   for ( ;; ) {
      gettch(infile, tch);
      if (putdch(infile, tch) == EOF) return;
   }
}

/*
 * getuch: read a Unicode character
 */
int getuch(FILE *infile) {
   int uch, ch;
   if (queueduch != 0) {
      uch = queueduch;
      queueduch = 0;
      return(uch);
   }
   if (il == 1) {			/* Little-endian UCS-2 input */
      uch = getc(infile);
      if (uch == EOF) return(EOF);
      ch = getc(infile);
      if (ch == EOF) return(EOF);
      uch = uch | (ch << 8);
      return(uch);
   }
   else if (ib == 1) {			/* Big-endian UCS-2 input */
      ch = getc(infile);
      if (ch == EOF) return(EOF);
      uch = ch << 8;
      ch = getc(infile);
      if (ch == EOF) return(EOF);
      uch = uch | ch;
      return(uch);
   }
   else {				/* UTF-8 input */
      uch = getc(infile);
      if (uch == EOF) return(EOF);
      if ((uch & 0x80) == 0) return(uch);
      else if ((uch & 0xE0) == 0xC0) {
	 uch = (uch & 0x1F) << 6;
	 ch = getc(infile);
	 if (ch == EOF) return(EOF);
	 uch |= (ch & 0x3F);
      }
      else {
	 uch = (uch & 0x0F) << 12;
	 ch = getc(infile);
	 if (ch == EOF) return(EOF);
	 uch |= (ch & 0x3F) << 6;
	 ch = getc(infile);
	 if (ch == EOF) return(EOF);
	 uch |= (ch & 0x3F);
      }
      return(uch);
   }
}

/*
 * putuch: write a Unicode character
 */
void putuch(int uch) {
   if (ol == 1) {			/* little-endian UCS-2 outnput */
      fputc((unsigned char) (uch), stdout);
      fputc((unsigned char) (uch >> 8), stdout);
      return;
   }
   if (ob == 1) {			/* big-endian UCS-2 output */
      fputc((unsigned char) (uch >> 8), stdout);
      fputc((unsigned char) (uch), stdout);
      return;
   }
   if (uch > 0x7FF) {			/* UTF-8 output */
      fputc((unsigned char) (((uch >> 12) & 0xF) | 0xE0), stdout);
      fputc((unsigned char) (((uch >> 6) & 0x3F) | 0x80), stdout);
      fputc((unsigned char) ((uch & 0x3F) | 0x80), stdout);
      return;
   }
   if (uch > 0x7F) {
      fputc((unsigned char) (((uch >> 6) & 0x1F) | 0xC0), stdout);
      fputc((unsigned char) ((uch & 0x3F) | 0x80), stdout);
      return;
   }
   fputc((unsigned char) uch, stdout);
   return;
}

/*
 * gettch: read a transliteration character and store it in a
 * buffer (null terminated)
 */
void gettch(FILE *infile, int tch[]) {
   unsigned char i;
   const char istring[] = {'i', 'I', igrave, iacute, Igrave, Iacute, '\0'};
   const char ustring[] = {'u', 'U', ugrave, uacute, Ugrave, Uacute, '\0'};
   const char ascstopstring[] = "kKgGcCjJtTdDpPbB";
   if (*queuedtch != 0) {
      for (i = 0; queuedtch[i] != 0; i++) tch[i] = queuedtch[i];
      tch[i] = 0;
      for (i = 0; i < TSIZE; i++) queuedtch[i] = 0;
      return;
   }
   tch[0] = getuch(infile);
   if (tch[0] == EOF) return;
   tch[1] = getuch(infile);
   /*
    * Check for and simplify ai, au and capitalised and accented
    * variants
    */
   if (((tch[0] == 'a') || (tch[0] == 'A'))
       && (strchr(istring, tch[1]) != NULL) && (tch[1] >> 8 == 0)) {
      tch[1] = 'i';
      tch[2] = 0;
      return;
   }
   if (((tch[0] == 'a') || (tch[0] == 'A'))
       && ((tch[1] == itilde) || (tch[1] == Itilde))) {
      tch[1] = itilde;
      tch[2] = 0;
      return;
   }
   if (((tch[0] == 'a') || (tch[0] == 'A'))
       && (strchr(ustring, tch[1]) != NULL) && (tch[1] >> 8 == 0)) {
      tch[1] = 'u';
      tch[2] = 0;
      return;
   }
   if (((tch[0] == 'a') || (tch[0] == 'A'))
       && ((tch[1] == utilde) || (tch[1] == Utilde))) {
      tch[1] = utilde;
      tch[2] = 0;
      return;
   }
   /*
    * Check for and simplify aspirate stops including capitalised
    * variants
    */
   if ((((strchr(ascstopstring, tch[0]) != NULL) && (tch[0] >> 8 == 0))
       || ((tch[0] == tdot) || (tch[0] == Tdot)
	   || (tch[0] == ddot) || (tch[0] == Ddot)))
       && ((tch[1] == 'h') || (tch[1] == 'H'))) {
      tch[1] = 'h';
      tch[2] = 0;
      return;
   }
   /*
    * Now ensure buffer contains a complete transliteration character
    * and is null terminated
    */
   if ((tch[1] >> 8) != 0x03) {
      queueduch = tch[1];
      tch[1] = 0;
      return;				/* 1-codepoint char */
   }
   tch[2] = getuch(infile);
   if (tch[2] == EOF) return;
   if (tch[1] == 0x035F) {
     tch[3] = 0;
     return;
   }
   if ((tch[2] >> 8) != 0x03) {
     queueduch = tch[2];
     tch[2] = 0;
     return;				/* 2-codepoint char */
   }
   tch[3] = getuch(infile);
   if (tch[3] == EOF) return;
   if ((tch[3] >> 8) != 0x03) {
     queueduch = tch[3];
     tch[3] = 0;
     return;				/* 3-codepoint char */
   }
   tch[4] = 0;
   return;				/* 4-codepoint char */
}


/*
 * putdch: write a (possibly) Devanagari character
 */
int putdch (FILE *infile, int *tchptr) {
   int *p;
   unsigned char i;
   struct ur2ud *up;
   /*
    * Deal with ":" (separator character)
    */
   if ((*tchptr == ':') && (*(tchptr + 1) == 0)) {
      if ((sylstate == OTHER) && (skt == 1)) {
	 putuch(':');
	 return(1);
      }
      gettch(infile, queuedtch);
      if (skt == 0) {
	 if (((*queuedtch == '\'') || (*queuedtch == APOSTR))
	     && (*(queuedtch + 1) == 0)) {
	    if (sylstate == CONS) putuch(HALANT);
	    putuch(AVAGRAHA);
	    sylstate = NEW;
	    for (i = 0; i < TSIZE; i++) queuedtch[i] = 0;
	    return(1);
	 }
      }
      if (lookup(queuedtch) != NULL) return(1);
   }
   /*
    * Deal with space character (omitted in Sanskrit after consonant
    * and before avagraha)
    */
   if ((*tchptr == ' ') && (*(tchptr + 1) == 0)) {
      if (skt == 1) {
	 gettch(infile, queuedtch);
	 if  ((sylstate == CONS) && (lookup(queuedtch) != NULL)) return(1);
	 if ((sylstate == NEW)
	     && ((*queuedtch == '\'') || (*queuedtch == APOSTR))
	     && (*(queuedtch + 1) == 0))
	   return(1);
      }
   }
   /*
    * Deal with apostrophe preceding anusvara in Sanskrit
    */
   else if (((*tchptr == '\'') || (*tchptr == APOSTR))
	    && (*(tchptr + 1) == 0)) {
      if (skt == 1) {
	 gettch(infile, queuedtch);
	 if (((*queuedtch == mdot) || (*queuedtch == Mdot))
	     && (*(queuedtch + 1) == 0)) {
	    *tchptr = mdot;
	    *queuedtch = '\'';
	 }
      }
   }
   /*
    * Now look up the character in the conversion table
    */
   if ((up = lookup(tchptr)) != NULL) {
      /*
       * Found it in table -- now output the Devanagari equivalent
       */
      if ((sylstate == NEW) || (sylstate == OTHER)) {
	 for (p = up->dch1; *p != 0; p++) putuch(*p);
	 if (*(up->dch2) == CONS) sylstate = CONS;
	 else sylstate = NEW;
      }
      else if (*(up->dch2) == CONS) {
	 putuch(HALANT);
	 for (p = up->dch1; *p != 0; p++) putuch(*p);
      }
      else {
	 for (p = up->dch2; *p != 0; p++) putuch(*p);
	 sylstate = NEW;
      }
   }
   else {
      /*
       * Didn't find it in table -- output it verbatim
       */
      if (sylstate == CONS) putuch(HALANT);
      for (p = tchptr; *p != 0; p++) {
	 if (*p == EOF) return(EOF);
	 else putuch(*p);
      }
      sylstate = OTHER;
   }
   return(1);
}

/*
 * lcharcmp: compare two possibly "long" (multi-codepoint) Unicode
 * chars. Works just like strcmp().
 */
int lcharcmp(int *ch1, int *ch2) {
   for ( ; *ch1 == *ch2; ch1++, ch2++)
     if (*ch1 == 0) return(0);
   return(*ch1 - *ch2);
}

/*
 * lchardup: duplicate a possibly "long" (multi-codepoint) Unicode
 * char and return a pointer to it. Second argument is the size of
 * the lchar array.
 */
int *lchardup(int *uch, unsigned char size) {
   int *new;
   unsigned char i;
   if ((new = malloc(size * sizeof(int))) != NULL)
     for (i = 0; i < size; i++) new[i] = uch[i];
   return(new);
}

/*
 * lookup: look for a transliteration char in the conversion table.
 * This and install() below are shamelessly plagiarised from
 * Kernighan and Ritchie 2nd ed, p. 145. However, our convtab[] is
 * indexed not with a hash value but with the least significant
 * byte of the first char of the transliteration character.
 */
struct ur2ud *lookup(int *tchptr) {
   struct ur2ud *up;
   for (up = convtab[(unsigned char) *tchptr]; up != NULL; up = up->next)
     if (lcharcmp(tchptr, up->tch) == 0)
       return(up);			/* found */
   return(NULL);			/* not found */
}

/*
 * install: create an entry in the conversion table
 */
struct ur2ud *install(int *tch, int *dch1, int *dch2) {
   struct ur2ud *up;
   unsigned char num;
   if ((up = lookup(tch)) == NULL) {	/* not found */
      up = (struct ur2ud *) malloc(sizeof(*up));
      if (up == NULL || (up->tch = lchardup(tch, TSIZE)) == NULL)
	return(NULL);
      num = (unsigned char) *tch;
      up->next = convtab[num];
      convtab[num] = up;
   }
   else {				/* remove old definition */
      free((void *) up->dch1);
      free((void *) up->dch2);
   }
   if (((up->dch1 = lchardup(dch1, DSIZE)) == NULL)
       || ((up->dch2 = lchardup(dch2, DSIZE)) == NULL))
     return(NULL);
   return(up);
}

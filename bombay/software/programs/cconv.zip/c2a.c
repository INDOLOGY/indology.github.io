/*
 * a2c
 *
 * A program to convert romanised Sanskrit text from CSX to
 * Harvard-Kyoto ASCII
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAXLINE 1000

int main(int argc, char *argv[]);
void process(FILE *infile);
int getline(unsigned char line[MAXLINE], int max, FILE *infile);
char *tr(char *line, char *is, char *os);
int chindex(char s[], char t);

int main(int argc, char *argv[]) {
  char infname[128];
  FILE *infile;
  if (argc > 1) {
    strcpy(infname, argv[1]);
    if ((infile = fopen(infname, "r")) == NULL) {
      fputs("\nUnable to open file\n", stderr);
      exit(1);
    }
    process(infile);
    fclose(infile);
  }
  else process(stdin);
  exit(0);
}

/* process: do the job */
void process(FILE *infile) {
  char *line;
  static char array[MAXLINE];
  line = array;
  while (getline(line, MAXLINE, infile) > 0) {
    line = tr(line, "���������������", "AIURqLHM&GJTDNzS");
    fputs(line, stdout);
  }
}

/* getline: read a line, return length */
int getline(unsigned char line[MAXLINE], int max, FILE *infile) {
  if (fgets(line, max, infile) == NULL) return 0;
  else return strlen(line);
}

/* tr: replace each "is" char by equivalent "os" char in a line */
char *tr(char *line, char *is, char *os) {
  static char s[MAXLINE];
  int i, len, val;
  strcpy(s, line);
  len = strlen(s);
  for (i = 0; i <= len; i++) {
    val = chindex(is, s[i]);
    if (val != -1) s[i] = os[val];
  }
  return s;
}

/* chindex: return index of t in s, -1 if none */
int chindex(char s[], char t) {
  int i;
  for (i = 0; s[i] != '\0'; i++) {
    if (s[i] == t) return i;
  }
  return -1;
}

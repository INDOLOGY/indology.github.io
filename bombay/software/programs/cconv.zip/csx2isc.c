/*
 *   csx2iscii: C version. Convert CSX text to ISCII.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXLINE 1000
#define CONS  "kKgG�cCjJ������tTdDnpPbBmyrlv��sh"
#define VOWEL "a�i�u����eo"
#define CSX   "�I�U����EO��kKgG�cCjJ������tTdDnpPbBmyrlv��sh���a�i�u����eo'"
#define ISC   "����������泴������������������������������آ��������������"

int main (int argc, char *argv []);
void process (FILE *infile);
char *doline (char *p);
int getline(char line[MAXLINE], int max, FILE *infile);
int chindex(char s[], char t);
char *sc(char *line);
char *ge(char *line, char *is, char *os);
char *mv(char *line);
char *ce(char *line, char *is, char *os);
char *ve(char *line, char *is, char *os);
char *hl(char *line);
char *tr(char *line, char *is, char *os);
char *sk(char *line);

int main (int argc, char *argv []) {
   char infname [128];
   FILE *infile;
   if (argc > 1) {
      strcpy(infname, argv[1]);
      if ((infile = fopen(infname, "r")) == NULL) {
         fputs("\nUnable to open file\n", stderr);
         exit (1);
      }
      process (infile);
      fclose (infile);
   }
   else process (stdin);
   exit (0);
}

/* process: do the job */
void process (FILE *infile) {
   char *line, *p, *s;
   static char array[MAXLINE];
   line = array;
   while (getline(line, MAXLINE, infile) > 0) {
      fputs(doline(line), stdout);
   }
}

/* doline: translate a line of text */
char *doline (char *p) {
   char *s, *nl;
   static char array[MAXLINE];
   s = array;
   strcpy(s, p);
   *p = '\0';
   s = ge(s, " '", "'");	/* Eliminate spaces before avagraha */
   s = ge(s, "'�", "�'");	/* Avagraha/anusv�ra combination */
   s = sc(s);			/* Force single-character representation */
   s = ge(s, "�", "i");
   s = ge(s, "�", "u");
   s = ve(s, "�", "");	/* Differentiate non-vocalic � */
   s = ce(s, " ", "");		/* Join up words ending in consonants */
   s = hl(s);			/* See to halant */
   s = mv(s);			/* Eliminate inherent a
			 	 * and see to matra vowels */
   s = tr(s, CSX, ISC);		/* Now do the conversion */
   /*
    *   Sanskrit-only characters -- quicker than using special function!
    */
   s = ge(s, "", "��");	/* Avagraha */
   s = ge(s, "", "��");	/* Long vocalic r (matra) */
   s = ge(s, "", "��");	/* Vocalic l (matra) */
   s = ge(s, "", "��");	/* Long vocalic r (initial) */
   s = ge(s, "", "��");	/* Vocalic l (initial) */
   s = ge(s, "|", "�");		/* Da��a */
   return(s);
}


/* getline: read a line, return length */
int getline(char line[MAXLINE], int max, FILE *infile) {
   if (fgets(line, max, infile) == NULL) return 0;
   else return strlen(line);
}

/* chindex: return index of t in s, -1 if none */
int chindex(char s[], char t) {
   int i;
   for (i = 0; s[i] != '\0'; i++) {
      if (s[i] == t) return i;
   }
   return -1;
}

/* sc: replace 2-char Skt characters by 1-char placeholders */
char *sc(char *line) {
   char *is = "kgcj��tdpb", *os = "KGCJ��TDPB"; static char s[MAXLINE];
   int i, j, len, val;
   len = strlen(line);
   for (i = 0, j = 0; i <= len; i++, j++) {
      if (line[i] == 'a' && line[i + 1] == 'i') {
	 s[j] = '';
	 i++;
	 continue;
      }
      if (line[i] == 'a' && line[i + 1] == 'u') {
	 s[j] = '';
	 i++;
	 continue;
      }
      val = chindex(is, line[i]);
      if (val != -1 && line[i + 1] == 'h') {
	 s[j] = os[val];
	 i++;
      }
      else s[j] = line[i];
   }
   return s;
}

/* mv: after consonant eliminate "a" and differentiate other vowels */
char *mv(char *line) {
   char *is = "�i�u����eo", *os = "�I�U����EO��"; static char s[MAXLINE];
   int i, j, len, val;
   len = strlen(line);
   for (i = 0, j = 0; i <= len; i++, j++) {
      if (strchr(CONS, line[i]) == NULL) {
	 s[j] = line[i];
	 continue;
      }
      if (line[i + 1] == 'a') {
	 s[j] = line[i++];
	 continue;
      }
      val = chindex(is, line[i + 1]);
      if (val != -1) {
	 s[j++] = line[i++];
	 s[j] = os[val];
      }
      else s[j] = line[i];
   }
   return s;
}

/* ge: globally replace a string in a line */
char *ge(char *line, char *is, char *os) {
   char *p, *pp; static char s1[MAXLINE], s2[MAXLINE];
   int found = 0;
   strcpy(s1, line);
   pp = s1;
   while ((p = strstr(pp, is))) {
      found++;
      *p = '\0';
      pp = p + strlen(os);
      p += strlen(is);
      strcpy(s2, p);
      strcat(strcat(s1, os), s2);
   }
   if (found) line = s1;
   return line;
}

/* ce: globally replace a string following a consonant in a line
   provided a letter character follows */
char *ce(char *line, char *is, char *os) {
   char *p, *pp; static char s1[MAXLINE], s2[MAXLINE];
   int found = 0;
   int islen = strlen(is);
   strcpy(s1, line);
   pp = s1;
   while ((p = strpbrk(pp, CONS))) {
      if (strncmp(++p, is, islen) == 0 && strchr(CSX, *(p + islen)) != NULL) {
	 found++;
	 *p = '\0';
	 strcpy(s2, p + strlen(is));
	 strcat(strcat(s1, os), s2);
      }
      pp = p;
   }
   if (found) line = s1;
   return line;
}

/* ve: globally replace a string following a vowel in a line */
char *ve(char *line, char *is, char *os) {
   char *p, *pp; static char s1[MAXLINE], s2[MAXLINE];
   int found = 0;
   strcpy(s1, line);
   pp = s1;
   while ((p = strpbrk(pp, VOWEL))) {
      if (strncmp(++p, is, strlen(is)) == 0) {
	 found++;
	 *p = '\0';
	 strcpy(s2, p + strlen(is));
	 strcat(strcat(s1, os), s2);
      }
      pp = p;
   }
   if (found) line = s1;
   return line;
}

/* hl: globally insert ^S (halant) between consonant and non-vowel in a line */
char *hl(char *line) {
   char *p, *pp; static char s1[MAXLINE], s2[MAXLINE];
   int found = 0;
   strcpy(s1, line);
   pp = s1;
   while ((p = strpbrk(pp, CONS))) {
      if (strcspn(++p, VOWEL) > 0) {
	 found++;
	 strcpy(s2, p);
	 *p = '\0';
	 strcat(strcat(s1, ""), s2);
      }
      pp = p;
   }
   if (found) line = s1;
   return line;
}

/* tr: replace each "is" char by equivalent "os" char in a line */
char *tr(char *line, char *is, char *os) {
   static char s[MAXLINE];
   int i, len, val;
   strcpy(s, line);
   len = strlen(s);
   for (i = 0; i <= len; i++) {
      val = chindex(is, s[i]);
      if (val != -1) s[i] = os[val];
   }
   return s;
}

/* sk: replace 1-char Skt placeholders by 2-char characters */
/* Not in fact used: it seems quicker to do individual ge substitutions */
char *sk(char *line) {
   char *is = "", *os = "��۪�"; static char s[MAXLINE];
   int i, j, len, val;
   len = strlen(line);
   for (i = 0, j = 0; i <= len; i++, j++) {
      val = chindex(is, line[i]);
      if (val != -1) {
	 s[j++] = os[val];
	 s[j] = '�';
      }
      else s[j] = line[i];
   }
   return s;
}

WORD MACROS
===========

IMPORTANT NOTE MAC USERS
========================

As of Word 2008, Microsoft have withdrawn VBA (Visual Basic for
Applications) from the Macintosh release of the program. This means
that macros such as those described here will no longer work. Some
people are opting not to upgrade to Word 2008 for precisely this
reason.

Document conversion macros
==========================

The files whose names begin "n2u" and "c2u" are Word macros to convert
Word documents from the legacy character sets CSX+ and Norman to
Unicode. It is important to choose the right one(s) for your
requirements:

* c2u_mac.txt converts a CSX+ document prepared on a Macintosh up to
  and including Mac OS X Panther; it will work under either Mac OS X
  Tiger (and upwards, I hope) or a reasonably up-to-date Windows.

* c2u_pc.txt converts a CSX+ document prepared on a PC; it will work
  under either Mac OS X Tiger (and upwards, I hope) or a reasonably
  up-to-date Windows.

* n2u_mac.txt converts a Norman document prepared on a Macintosh up to
  and including Mac OS X Panther; it will work under Mac OS X Tiger
  (and upwards, I hope).

* n2u_mac2pc.txt converts a Norman document prepared on a Macintosh up
  to and including Mac OS X Panther; it will work under a reasonably
  up-to-date Windows.

* n2u_pc.txt converts a Norman document prepared on a PC; it will work
  under either Mac OS X Tiger (and upwards, I hope) or a reasonably
  up-to-date Windows.

For installation instructions see below.

These macros are written to convert from the fonts Times CSX+ and
Times Norman to the equivalent IndUni font, which is named IndUni-T.
(IndUni-T is available as freeware at http://bombay.indology.info/
software/fonts/induni/index.html.) You must make sure the relevant
fonts exist on your system before attempting to run a macro.
Alternatively, you can edit the macro text to make appropriate changes
to .Font.Name and .Replacement.Font.Name.

To convert a file, open it in Word and make sure your cursor is
situated at the beginning of the document. Click on "Tools", and
select Macro -> Macros. You will see a menu of available macros.
Select the relevant one, and click on "Run". Note that the conversion
make take some time to complete, especially if the file is large or
complex.

Remember that Word treats footnotes, headers, footers etc. as quite
separate sub-documents, each of which will have to be separately
converted. If the file contains footnotes, for example, position the
cursor before the start of the first note and run the macro again.

I have tested these macros as carefully as I can, but I cannot
guarantee that they will work with 100% success in every environment.
I *strongly* recommend you to run them on copies of your CSX+ and
Norman documents, and to keep the originals until you are quite
certain that the converted version is satisfactory.


Accent macros
=============

If you have installed a keyboard layout such as IndUni to gain access
to "special" accented characters, you will find that Word ignores most
of the keystrokes defined there. It is therefore necessary to find an
alternative way to insert "special" characters within the program. One
approach is to assign shortcuts from within the Insert -> Symbol menu,
but this has the disadvantage of inserting the character in question
in the font that you happened to be using when you created the
shortcut; if you call up the shortcut from within a different font the
result will look bad.

A better approach is to use a set of macros that call the characters
up by name. The file accent_macros.txt contains such a set,
concentrating on the "Indic" characters that cannot be reached in
other ways. Once these are installed, it is easy to assign keystrokes
to them. (For installation instructions see below.) Select Tools ->
Customize -> Keyboard. Scroll down the Categories list till you get to
Macros, and select that. You should see a list of available macros
including "acute", "amacron", etc. (Final "uc" in a macro name means
"upper case".) Now choose the ones you want to use and assign a
suitable shortcut to each.


Installation
============

To install any of these macros, start Word, click on Tools, and select
Macro -> Visual Basic Editor. If you already have some macros defined
in your "Normal" template (the one used by default), an editing window
showing these will appear. Move your cursor to the end of the file,
ready to insert the new macro text. If you do not already have any
macros, you should see in the top left of your screen a little window
with "Normal" as the first item in it. Right-click on this, and from
the drop-down menu choose Insert -> Module. It should now expand to
show you the folders associated with it; one of these should be called
"Modules", and it should contain your new module called "Module1".
Double-click on this: you will get an editing window.

From the Insert menu at the top of the screen, choose File, then
browse to where you have saved the .txt file(s) containing the
macro(s) you want to use, and click on "Open" to insert it. (You may
have to ask Word to give you access to "All files" rather than just
"Text files".) Lastly, click on the File menu at the top of the screen
and select "Save Normal". You should now have the macro available for
use in any document.


John D. Smith (jds10@cam.ac.uk)
July 5, 2007

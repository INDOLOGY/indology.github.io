This package is a keyboard layout designed for use with the IndUni
fonts, though it should work well also with any other fonts covering
the same range of characters. The layout can be used on the following
Windows systems: NT 4, 2000, XP, Vista, 7, in both 32-bit and 64-bit
versions where relevant. It cannot be used with Windows 95, Windows 98
or Windows ME. I am grateful to Bruce Graham for building this
multi-platform version for me.

To install the Induni layout, double-click on the file setup.exe in
this folder. This will make the layout available on your system; you
will then have to select it for your own use. You can do this by
right-clicking on the blue language icon on the taskbar and choosing
"Properties" or "Settings" (depending on what version of Windows you
are running). This will allow you to select the languages and keyboard
layouts that you wish to use. The IndUni layout is named "United
Kingdom IndUni", but it should work well on non-UK keyboards also.

The same menu can be reached via "Regional and Language Options" in
the Control Panel (Start => Settings).

(On Vista or Windows 7 systems, if clicking on setup.exe fails to
install the layout, you may need to disable Microsoft's User Account
Control mechanism (UAC). Go into the Control Panel and type "UAC" into
the search box. Follow the link that appears to "Turn User Account
Control (UAC) on or off", and then uncheck the box for "Use User
Account Control (UAC) to help protect your computer", and click "OK".
You will have to reboot for the change to come into effect.)

My object in designing the layout was to make all the special accented
characters in the IndUni fonts available from the keyboard.
Unfortunately Microsoft allow the keyboard designer only one method of
obtaining special "shifted" characters (so some ingenuity is needed to
accommodate the large number of extra characters contained in the
fonts). That method is to hold down the Ctrl and Alt keys
simultaneously, and then press the desired key. (The same effect can
be gained by holding down the "Alt Gr" key to the right of the
spacebar.) Since "Ctrl-Alt-A" is cumbersome, I am abbreviating it here
to "*A", but please bear in mind that this does not refer to the "*"
key.

There are three approaches to getting the character you want. The
simplest is a set of short-cuts made available for the commonest
"Indic" characters only. Pressing Ctrl + Alt + a character key will
produce the most usual "Indic" variant of that character. Thus *a
produces a-macron, *t produces t-underdot, etc. Upper-case versions
are also available (as with the other ways of using the keyboard
layout). *n gives n-underdot; for n-overdot press *k or *g, and for
n-tilde, press *c or *j. *s gives s-underdot; for s-acute press *x.
N.b.: on one of my systems, certain of these keys do not work (*d, *i,
*l). This is a problem with the system, not with the keyboard layout;
if you encounter the same difficulty, you will have to use one of the
other two approaches to secure the characters in question.

The second approach can be used for all "simple" Unicode characters
(i.e., for those which are defined as a single codepoint). A "dead
key" is defined which represents the accent in question: pressing the
dead key followed by the desired character key produces the accented
form of that character. For example, the "." key represents the
underdot accent; pressing *. (Ctrl-Alt-.) followed by "t" produces
t-underdot.

The dead keys are as follows:

Acute		*'
Breve		*%
Candrabindu	*!
Caron		** (Ctrl-Alt-*)
Cedilla		*,
Circumflex		*^
Dieresis		*"
Grave		*`
Macron		*=
Overdot		*:
Ring		*0
Slash		*/
Tilde		*~
Underbar		*_
Underdieresis	*&
Underdot		*.

Notes

Thorn and eth can be obtained as t-acute and d-acute. Breve yields
underbreve when used with the relevant characters (in fact only "h"
and "H"); similarly cedilla yields commaaccent or ogonek, overdot
yields hungarumlaut, and ring yields underring. Slash is used as
follows: */ + "a" produces "æ", */ +"d" produces "đ", */ + "e"
produces "œ", */ + "l" produces "ł", */ + "o" produces "ø", and */
+"s" produces "ß".

The third approach for producing the desired accented character is to
type the character and then type the appropriate dead key twice. This
is the only way to obtain "complex" Unicode characters (those
requiring more than one codepoint). For example, to obtain
r-underring, type "r" + *0 + *0. Further accents can be added:
r-underring-macron can be typed as "r" + *0 +*0 + *= +*=. (It's
simpler and quicker than it looks!) This approach can also be used for
"simple" characters such as e-acute, but will probably result in the
character being stored as "e" + "acute", rather than as the single
Unicode character for e-acute (U+00E9).

John Smith

This package is a Mac OS X keyboard layout designed for use with the
IndUni fonts, though it should work well also with any other fonts
covering the same range of characters.

To install the IndUni layout, copy the files IndUni.icns and
IndUni.keylayout to the folder Keyboard Layouts in your Library
folder. Log out and log back in again, then open "International"
(Leopard and earlier) or "Language and Text" (Snow Leopard) from
System Preferences, and select "Input Menu" (Leopard and earlier) or
"Input Sources" (Snow Leopard). (Input Menu/Input Sources may also be
available from your menu bar.) Scroll down to find the IndUni item and
check its box. You will now be able to choose the IndUni layout from
the menu bar (by clicking on the icon representing your current input
method).

An alternative is the DevUni layout, which is installed in the same
way (the files to copy are DevUni.icns and DevUni.keylayout). This is
the same as the IndUni layout, except that when Caps Lock is pressed,
the system switches to the Devanagari-QWERTY layout; this may be
convenient for people who use both Devanagari and accented Roman.

My object in designing the layout was to make all the special accented
characters in the IndUni fonts available from the keyboard using the
Opt (Alt) key in combination with reasonably memorable shortcut keys.

There are three approaches to getting the character you want. The
simplest is a set of short-cuts made available for the commonest
"Indic" characters only. Pressing Opt + a character key will produce
the most usual "Indic" variant of that character. Thus Opt-a produces
a-macron, Opt-t produces t-underdot, etc. Upper-case versions are also
available (as with the other ways of using the keyboard layout). Opt-n
gives n-underdot; for n-overdot press Opt-k or Opt-g, and for n-tilde,
press Opt-c or Opt-j. (In case this seems a strange choice, bear in
mind that the next character you type is almost bound to be k/g or
c/j.) Opt-s gives s-underdot; for s-acute press Opt-x.

The second approach can be used for all "simple" Unicode characters,
i.e., for those which are defined as a single codepoint (including all
normal European characters and most of the commoner "Indic" ones), as
well as for some common multi-codepoint characters (such as
r-underring). A "dead key" is defined which represents the accent in
question: pressing the dead key followed by the desired character key
produces the accented form of that character. For example, the "." key
represents the underdot accent; pressing Opt-. followed by "t"
produces t-underdot.

The dead keys are as follows:

Acute		Opt-'
Breve		Opt-%
Caron		Opt-*
Cedilla		Opt-,
Circumflex	Opt-^
Dieresis		Opt-"
Grave		Opt-`
Macron		Opt-=
Overdot		Opt-:
Ring		Opt-0
Slash		Opt-/
Tilde		Opt-~
Underbar	Opt-+
Underdot	Opt-.

Notes

Breve yields underbreve when used with the relevant characters (in
fact only "h" and "H"); similarly cedilla yields commaaccent or
ogonek, dieresis yields underdieresis, ring yields underring and tilde
yields candrabindu.

The slash "accent" is used as follows: Opt-/ + "a" produces "æ", Opt-/
+"d" produces "ð", Opt-/ + "e" produces "œ", Opt-/ + "l" produces "ł",
Opt-/ + "o" produces "ø", Opt-/ +"s" produces "ß", and Opt-/ +"t"
produces "þ".

The third approach for producing the desired accented character is to
type the character first and then the appropriate "dead key". This is
the only way to obtain the remaining "complex" Unicode characters
(those requiring more than one codepoint). For example, to obtain
r-underring-macron, type EITHER Opt-0 + "r" + Opt-= OR "r" + Opt-0 +
Opt-=.

The fact that a "dead key" can be typed either before or after a
letter character can lead to ambiguous situations: will Opt-a + Opt-'
+ "s" yield a-macron-acute + "s" or or a-macron + s-acute? In fact it
will yield the latter -- the genuine dead-key usage overrules the
"added accent" usage. To overcome this, you can type a space when any
added accent is still "pending" (in the present case, Opt-a + Opt-' +
Space + "s" will produce a-macron-acute + "s"). In such cases, no
space character is output, but the added accent is now fixed in place
and there is no dead-key effect.

This approach could also be used for "simple" characters such as
e-acute, but this is likely to result in the character being stored as
"e" + "acute", rather than as the single Unicode character for e-acute
(U+00E9), which should be avoided if possible.

John Smith
